<?php 
    // initialize errors variable
	$errors = "";

	// connect to database
	$db = mysqli_connect("localhost", "root", "", "todolist");

	// insert a quote if submit button is clicked
	if (isset($_POST['submit'])) {
		if (empty($_POST['task'])) {
			$errors = "You must fill in the task";
		}else{
			$task = $_POST['task'];
			$sql = "INSERT INTO tasks (task) VALUES ('$task')";
			mysqli_query($db, $sql);
			header('location: index.php');
		}
	}

	//deletin a task
	 if (isset($_GET['del_task'])) {
	 	$id = $_GET['del_task'];
	 	mysqli_query($db, "DELETE FROM tasks WHERE id =$id" );

	 	# code...
	 }
	 $task = mysqli_query($db, "SELECT * FROM tasks ");
	 header('location; index.php');
	?>	


<!DOCTYPE html>
<html>
<head>
	<title>todo list application with php</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="heading">
	<h2>This is my todo list application with php</h2>
</div>

<form method="post" action="index.php">
	<?php if (isset($errors)){ ?>
	<p><?php echo $errors;?></p>
	<?php }?>

     <input type="text" name="task" class="task-input">
	<button type="submit" class="add_btn" name="submit">Add task</button>
</form>
	<table>
		<thead>
			<tr>
				<th>N</th>
				<th>Task</th>
				<th>Action</th>
			</tr>
		</thead>
	

	<tbody>
			<?php 
		// select all tasks if page is visited or refreshed
		$tasks = mysqli_query($db, "SELECT * FROM tasks");

		$i = 1; while ($row = mysqli_fetch_array($tasks)) { ?>
			<tr>
				<td> <?php echo $i; ?> </td>
				<td class="task"> <?php echo $row['task']; ?> </td>
				<td class="delete"> 
					<a href="index.php?del_task=<?php echo $row['id'] ?>">x</a> 
				</td>
			</tr>
		<?php $i++; } ?>
	</tbody>
	</table>

</body>
</html>